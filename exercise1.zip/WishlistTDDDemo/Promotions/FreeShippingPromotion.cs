﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Promotions
{
    public class FreeShippingPromotion : IPromotion
    {
        public bool PromotionApplies(decimal wishlistTotal)
        {
            bool applies = false;

            if (wishlistTotal < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            else if (wishlistTotal > 50)
            {
                return true;
            }

            return applies;

        }
    }
}
