﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Promotions
{
    public class TwentyOffPromotion : IPromotion
    {
        public bool PromotionApplies(decimal wishlistTotal)
        {
            bool applies = false;

            if (wishlistTotal < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            else if (wishlistTotal > 200)
            {
                return true;
            }

            return applies;

        }
    }
}
