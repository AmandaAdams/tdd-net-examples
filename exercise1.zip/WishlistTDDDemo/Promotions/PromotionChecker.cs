﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Promotions
{
    public class PromotionChecker
    {
        public List<IPromotion> GetPromotions(decimal wishlistTotal)
        {
            if (wishlistTotal < 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            var promotions = new List<IPromotion>();

            var freeShipping = new FreeShippingPromotion();
            if (freeShipping.PromotionApplies(wishlistTotal))
            {
                promotions.Add(freeShipping);
            }

            var twentyOff = new TwentyOffPromotion();
            if (twentyOff.PromotionApplies(wishlistTotal))
            {
                promotions.Add(twentyOff);
            }

            return promotions;

        }
    }
}
