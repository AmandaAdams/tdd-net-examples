using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Promotions;

namespace WishlistTDDDemoTests.FreeShippingPromotionClass
{
    [TestClass]
    public class TestGetPromotions
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeTotalThrowsArgumentOutofRangeException()
        {
            PromotionChecker checker = new PromotionChecker();
            checker.GetPromotions(-1);
        }

        [TestMethod]
        public void NoPromotionsAreValidListIsEmpty()
        {
            PromotionChecker checker = new PromotionChecker();
            for (int i = 0; i <= 50; i++)
            {
                Assert.AreEqual(0, checker.GetPromotions(i).Count);

            }
        }

        [TestMethod]
        public void FreeShippingAppliesListContainsFreeShipping()
        {
            PromotionChecker checker = new PromotionChecker();
            List<IPromotion> promotions = checker.GetPromotions(50.01m);
            Assert.AreEqual(1, promotions.Count);
            CollectionAssert.AllItemsAreInstancesOfType(
                promotions, typeof(FreeShippingPromotion));

        }

        [TestMethod]
        public void TwentyOffAndFreeShippingAppliesListContainsBoth()
        {
            PromotionChecker checker = new PromotionChecker();
            List<IPromotion> promotions = checker.GetPromotions(200.01m);
            Assert.AreEqual(2, promotions.Count);
            Assert.IsInstanceOfType(promotions[0], 
                typeof(FreeShippingPromotion));
            Assert.IsInstanceOfType(promotions[1],
                typeof(TwentyOffPromotion));
        }

    }
}
