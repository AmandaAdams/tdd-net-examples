using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Promotions;

namespace WishlistTDDDemoTests.Promotions.FreeShippingPromotionClass
{
    [TestClass]
    public class TestApplyPromotion
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeTotalThrowsArgumentOutofRangeException()
        {
            FreeShippingPromotion promotion = new FreeShippingPromotion();
            promotion.PromotionApplies(-1);
        }

        [TestMethod]
        public void TotalBetweenZeroAnd50ReturnsFalse()
        {
            FreeShippingPromotion promotion = new FreeShippingPromotion();
            for (int i = 0; i <= 50; i++)
            {
                Assert.IsFalse(promotion.PromotionApplies(i));
            }
        }

        [TestMethod]
        public void TotalGreaterThan50ReturnsTrue()
        {
            FreeShippingPromotion promotion = new FreeShippingPromotion();
            Assert.IsTrue(promotion.PromotionApplies(50.01m));
        }
    }
}
