﻿using OpenQA.Selenium;
using System.Collections.Generic;

namespace WishlistTDDDemoPostDeployTests.WishlistWebSite.Pages
{
    public class ListPage
    {
        IWebDriver driver;

        public ListPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public IReadOnlyCollection<IWebElement> GetTxtName()
        {
            return driver.FindElements(By.Name("name"));
        }

        public IReadOnlyCollection<IWebElement> GetTxtId()
        {
            return driver.FindElements(By.Name("id"));
        }

        public IWebElement GetTxtNoProductsMessage()
        {
            return driver.FindElement(By.Id("noprods"));
        }

    }
}
