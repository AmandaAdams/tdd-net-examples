using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;
using System.Collections.Generic;
using System.Data.SqlClient;
using WishlistTDDDemoPostDeployTests.WishlistWebSite.Pages;

namespace WishlistTDDDemoPostDeployTests.WishlistWebSite.Controllers.ProductsControllerClass
{
    [TestClass]
    public class List
    {
        private const string CONNECTION_STRING = "Server=DRAGON-LAPPY\\SQLEXPRESS;Database=tdd;Trusted_Connection=True;MultipleActiveResultSets=true";
        private const string INSERT_STRING = "insert into dbo.PRODUCT ([ID], [Name]) VALUES (@ID, @NAME)";
        private const string DELETE_STRING = "delete from dbo.PRODUCT";

        [TestMethod]
        public void NoValidProductsCheckBackLaterDisplays()
        {
            RemoveAllProducts();

            using (var driver = new ChromeDriver())
            {
                driver.Navigate().GoToUrl("http://localhost:51984/products/list");
                ListPage page = new ListPage(driver);
                Assert.AreEqual("Check back later!", page.GetTxtNoProductsMessage().Text);
            }
        }

        [TestMethod]
        public void ValidProductsAllValidProductsDisplay()
        {
            RemoveAllProducts();

            IDictionary<int, string> products = new Dictionary<int, string>();
            products.Add(1, "Testing");
            products.Add(2, "Testing 2");
            products.Add(3, "Testing 3");

            InsertProducts(products);

            using (var driver = new ChromeDriver())
            {
                driver.Navigate().GoToUrl("http://localhost:51984/products/list");
                ListPage page = new ListPage(driver);

                Assert.AreEqual(3, page.GetTxtName().Count);
                Assert.AreEqual(3, page.GetTxtId().Count);
            }

            RemoveAllProducts();
        }

        [TestMethod]
        public void InValidProductDoesNotDisplay()
        {
            RemoveAllProducts();

            IDictionary<int, string> products = new Dictionary<int, string>();
            products.Add(1, "Testing");
            products.Add(2, "Testing 2");
            products.Add(3, "Testing 3");
            products.Add(27, "Testing 27");

            InsertProducts(products);
            using (var driver = new ChromeDriver())
            {
                driver.Navigate().GoToUrl("http://localhost:51984/products/list");
                ListPage page = new ListPage(driver);

                Assert.AreEqual(3, page.GetTxtName().Count);
                Assert.AreEqual(3, page.GetTxtId().Count);

            }

            RemoveAllProducts();
        }
    

        private void InsertProducts(IDictionary<int, string> products)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand command = new SqlCommand("SET IDENTITY_INSERT dbo.Product ON", connection);
                connection.Open();
                command.ExecuteNonQuery();
                foreach (int key in products.Keys) { 
                    command = new SqlCommand(INSERT_STRING, connection);
                    command.Parameters.AddWithValue("@ID", key);
                    command.Parameters.AddWithValue("@NAME", products[key]);
                    command.ExecuteNonQuery();
                   
                }
                connection.Close();
            }

        }

        private void RemoveAllProducts()
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand command = new SqlCommand(DELETE_STRING, connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

        }
    }
}
