﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace ProductValidationAPI.Controllers
{
    [Route("isValid")]
    public class ValidationController : Controller
    {
        [HttpGet("{id}")]
        public string IsValid(int id)
        {
            if (id != 27)
                return "{ \"id\": " + id + ", \"valid\": true }";
            else
               return "{ \"id\": " + id + ", \"valid\": false }";
        }

    }
}
