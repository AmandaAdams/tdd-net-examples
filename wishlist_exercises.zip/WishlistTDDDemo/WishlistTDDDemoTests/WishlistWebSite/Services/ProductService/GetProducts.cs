﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using WishlistWebSite.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using WishlistWebSite.Data;
using WishlistWebSite.Services;

namespace WishlistTDDDemoTests.WishlistWebSite.Services.ProductServiceClass
{
    [TestClass]
    public class GetProducts : DBStubbable
    {
        [TestMethod]
        public void NoProductsInDatabaseNoProductsDisplay()
        {
            List<Product> products = new List<Product>();

            ProductService productService =
                new ProductService(getStubContext(products), getStubValidationService(true));

            products = productService.GetProducts();

            Assert.AreEqual(0, products.Count);

        }

        [TestMethod]
        public void ProductsInDatabaseNoneValidNoProductsDisplay()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
                new Product { Name = "ZZZ", ID = 2 },
                new Product { Name = "AAA", ID = 3 },
            };

            ProductService productService =
                new ProductService(getStubContext(products), getStubValidationService(false));

            products = productService.GetProducts();

            Assert.AreEqual(0, products.Count);

        }

        [TestMethod]
        public void ProductsInDatabaseAllValidAllDisplay()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
                new Product { Name = "ZZZ", ID = 2 },
                new Product { Name = "AAA", ID = 3 },
            };

            ProductService productService =
                new ProductService(getStubContext(products), getStubValidationService(true));

            List<Product> returnedProducts = productService.GetProducts();

            Assert.AreEqual(3, products.Count);
            foreach (Product product in products) {
                CollectionAssert.Contains(returnedProducts, product);
            }

        }

        [TestMethod]
        public void ProductsInDatabaseSomeValidSomeDisplay()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
                new Product { Name = "ZZZ", ID = 2 },
                new Product { Name = "AAA", ID = 3 },
                new Product { Name = "YYY", ID = 4 },
            };

            var mockService = new Mock<IProductValidationService>();
            mockService.Setup(c => c.IsProductValid(It.IsIn<int>(new int[]{ 2,3})))
                .Returns(true);
            mockService.Setup(c => c.IsProductValid(It.IsIn<int>(new int[] { 1, 4 })))
                .Returns(false);

            ProductService productService =
                new ProductService(getStubContext(products), mockService.Object);

            List<Product> returnedProducts = productService.GetProducts();

            Assert.AreEqual(2, returnedProducts.Count);
            CollectionAssert.Contains(returnedProducts, products[1]);
            CollectionAssert.Contains(returnedProducts, products[2]);

        }

        private IProductValidationService getStubValidationService(bool expectedResult)
        {
            var mockService = new Mock<IProductValidationService>();
            mockService.Setup(c => c.IsProductValid(It.IsAny<int>())).Returns(expectedResult);

            return mockService.Object;
        }

    }
}
