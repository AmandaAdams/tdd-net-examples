﻿using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WishlistWebSite.Data;
using WishlistWebSite.Models;

namespace WishlistTDDDemoTests.WishlistWebSite.Services
{
    public class DBStubbable
    {
        protected WishlistWebSiteContext getStubContext(List<Product> stubProducts)
        {
            var data = stubProducts.AsQueryable();

            var mockSet = new Mock<DbSet<Product>>();
            mockSet.As<IQueryable<Product>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<Product>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<Product>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<Product>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            DbContextOptions options = new DbContextOptionsBuilder<WishlistWebSiteContext>().Options;

            var mockContext = new Mock<WishlistWebSiteContext>(options);
            mockContext.Setup(c => c.Product).Returns(mockSet.Object);

            return mockContext.Object;

        }
    }
}
