﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using WishlistWebSite.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using WishlistWebSite.Data;
using WishlistWebSite.Services;
using System;

namespace WishlistTDDDemoTests.WishlistWebSite.Services.WishlistServiceClass
{
    [TestClass]
    public class RemoveProduct : DBStubbable
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeIdThrowsArgumentOutofRangeException()
        {
            List<Product> products = new List<Product>();

            WishlistService wishlistService =
                new WishlistService(getStubContext(products));

            wishlistService.RemoveProduct(-1);

        }

        [TestMethod]
        public void NoProductsInWishlistProductDoesNotRemove()
        {
            List<Product> products = new List<Product>();

            WishlistService wishlistService =
                new WishlistService(getStubContext(products));

            Assert.IsFalse(wishlistService.RemoveProduct(1));
            Assert.AreEqual(0, wishlistService.Wishlist.Products.Count);

        }

        [TestMethod]
        public void ProductInWishlistProductRemoves()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
            };

            WishlistService wishlistService =
                new WishlistService(getStubContext(products));

            wishlistService.AddProduct(1);
            Assert.AreEqual(1, wishlistService.Wishlist.Products.Count);

            Assert.IsTrue(wishlistService.RemoveProduct(1));
            Assert.AreEqual(0, wishlistService.Wishlist.Products.Count);

        }

        [TestMethod]
        public void ProductNotInWishlistAndOtherProductsAreProductDoesNotRemove()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
                new Product { Name = "ZZZ", ID = 2 },
                new Product { Name = "AAA", ID = 3 },
            };

            WishlistService wishlistService =
                 new WishlistService(getStubContext(products));

            wishlistService.Wishlist.AddProduct(new Product { Name = "BBB", ID = 1 });
            wishlistService.AddProduct(2);
            Assert.AreEqual(2, wishlistService.Wishlist.Products.Count);

            Assert.IsFalse(wishlistService.RemoveProduct(3));
            Assert.AreEqual(2, wishlistService.Wishlist.Products.Count);

        }
    }
}
