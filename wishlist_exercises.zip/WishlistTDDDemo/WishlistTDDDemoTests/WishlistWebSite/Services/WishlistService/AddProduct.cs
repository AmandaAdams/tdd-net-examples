﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using WishlistWebSite.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using WishlistWebSite.Data;
using WishlistWebSite.Services;
using System;

namespace WishlistTDDDemoTests.WishlistWebSite.Services.WishlistServiceClass
{
    [TestClass]
    public class AddProduct : DBStubbable
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeIdThrowsArgumentOutofRangeException()
        {
            List<Product> products = new List<Product>();

            WishlistService wishlistService =
                new WishlistService(getStubContext(products));

            wishlistService.AddProduct(-1);

        }

        [TestMethod]
        public void ProductInDBAndFirstProductProductAdds()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
                new Product { Name = "ZZZ", ID = 2 },
                new Product { Name = "AAA", ID = 3 },
            };

            WishlistService wishlistService =
                new WishlistService(getStubContext(products));

            Assert.IsTrue(wishlistService.AddProduct(1));
            Assert.AreEqual(1, wishlistService.Wishlist.Products.Count);

        }

        [TestMethod]
        public void TwoProductsInDBAndNotInWishlistProductsAdd()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
                new Product { Name = "ZZZ", ID = 2 },
                new Product { Name = "AAA", ID = 3 },
            };

            WishlistService wishlistService =
                new WishlistService(getStubContext(products));

            wishlistService.Wishlist.AddProduct(new Product { Name = "BBB", ID = 1 });
            Assert.IsTrue(wishlistService.AddProduct(2));
            Assert.AreEqual(2, wishlistService.Wishlist.Products.Count);

        }

        [TestMethod]
        public void ProductInWishlistProductDoesNotAdd()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
                new Product { Name = "ZZZ", ID = 2 },
                new Product { Name = "AAA", ID = 3 },
            };

            WishlistService wishlistService =
                 new WishlistService(getStubContext(products));

            wishlistService.Wishlist.AddProduct(new Product { Name = "BBB", ID = 1 });
            Assert.IsFalse(wishlistService.AddProduct(1));
            Assert.AreEqual(1, wishlistService.Wishlist.Products.Count);

        }

        [TestMethod]
        public void ProductNotInDBProductDoesNotAdd()
        {
            List<Product> products = new List<Product>
            {
                new Product { Name = "BBB" , ID = 1 },
                new Product { Name = "ZZZ", ID = 2 },
                new Product { Name = "AAA", ID = 3 },
            };

            WishlistService wishlistService =
                 new WishlistService(getStubContext(products));

            Assert.IsFalse(wishlistService.AddProduct(7));
            Assert.AreEqual(0, wishlistService.Wishlist.Products.Count);

        }

    }
}
