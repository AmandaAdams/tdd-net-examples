using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Promotions;

namespace WishlistTDDDemoTests.Promotions.TwentyOffPromotionClass
{
    [TestClass]
    public class TestPromotionApplies
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeTotalThrowsArgumentOutofRangeException()
        {
            TwentyOffPromotion promotion = new TwentyOffPromotion();
            promotion.PromotionApplies(-1);

        }

        [TestMethod]
        public void TotalBetweenZeroAnd200ReturnsFalse()
        {
            TwentyOffPromotion promotion = new TwentyOffPromotion();
            for (int i = 0; i <= 200; i++)
            {
                Assert.IsFalse(promotion.PromotionApplies(i));
            }
        }

        [TestMethod]
        public void TotalGreaterThan200ReturnsTrue()
        {
            TwentyOffPromotion promotion = new TwentyOffPromotion();
            Assert.IsTrue(promotion.PromotionApplies(200.01m));
        }

    }
}
