using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Promotions;

namespace WishlistTDDDemoTests.PromotionCheckerClass
{
    [TestClass]
    public class TestGetPromotions
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeTotalThrowsArgumentOutofRangeException()
        {
            PromotionChecker checker = new PromotionChecker();
            checker.GetPromotions(-1, 1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeItemsThrowsArgumentOutofRangeException()
        {
            PromotionChecker checker = new PromotionChecker();
            checker.GetPromotions(1, -1);
        }


        [TestMethod]
        public void NoPromotionsAreValidListIsEmpty()
        {
            PromotionChecker checker = new PromotionChecker();
            for (int i = 0; i <= 50; i++)
            {
                for (int j  = 0; j <= 10; j++) {
                    Assert.AreEqual(0, checker.GetPromotions(i, j).Count);
                }

            }
        }

        [TestMethod]
        public void OnlyFreeToteBagListContainsFreeToteBag()
        {
            PromotionChecker checker = new PromotionChecker();
            List<IPromotion> promotions = checker.GetPromotions(50, 11);
            Assert.AreEqual(1, promotions.Count);
            CollectionAssert.AllItemsAreInstancesOfType(
                promotions, typeof(FreeToteBagPromotion));

        }

        [TestMethod]
        public void OnlyFreeShippingAppliesListContainsFreeShipping()
        {
            PromotionChecker checker = new PromotionChecker();
            List<IPromotion> promotions = checker.GetPromotions(50.01m, 10);
            Assert.AreEqual(1, promotions.Count);
            CollectionAssert.AllItemsAreInstancesOfType(
                promotions, typeof(FreeShippingPromotion));

        }

        [TestMethod]
        public void FreeShippingAndFreeToteBagAppliesListContainsBoth()
        {
            PromotionChecker checker = new PromotionChecker();
            List<IPromotion> promotions = checker.GetPromotions(50.01m, 11);
            Assert.AreEqual(2, promotions.Count);
            Assert.IsInstanceOfType(promotions[0],
                typeof(FreeShippingPromotion));
            Assert.IsInstanceOfType(promotions[1],
                typeof(FreeToteBagPromotion));

        }

        [TestMethod]
        public void TwentyOffAndFreeShippingAppliesListContainsBoth()
        {
            PromotionChecker checker = new PromotionChecker();
            List<IPromotion> promotions = checker.GetPromotions(200.01m, 10);
            Assert.AreEqual(2, promotions.Count);
            Assert.IsInstanceOfType(promotions[0], 
                typeof(FreeShippingPromotion));
            Assert.IsInstanceOfType(promotions[1],
                typeof(TwentyOffPromotion));
        }

        [TestMethod]
        public void TwentyOffAndFreeShippingAndFreeToteBagAppliesListContainsAllThree()
        {
            PromotionChecker checker = new PromotionChecker();
            List<IPromotion> promotions = checker.GetPromotions(200.01m, 11);
            Assert.AreEqual(3, promotions.Count);
            Assert.IsInstanceOfType(promotions[0],
                typeof(FreeShippingPromotion));
            Assert.IsInstanceOfType(promotions[1],
                typeof(TwentyOffPromotion));
            Assert.IsInstanceOfType(promotions[2],
                typeof(FreeToteBagPromotion));
        }

    }
}
