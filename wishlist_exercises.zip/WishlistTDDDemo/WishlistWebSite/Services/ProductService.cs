﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WishlistWebSite.Data;
using WishlistWebSite.Models;

namespace WishlistWebSite.Services
{
    public class ProductService : IProductService
    {
        private readonly WishlistWebSiteContext _context;
        private readonly IProductValidationService _validationService;

        public ProductService(WishlistWebSiteContext context, 
            IProductValidationService validationService)
        {
            _context = context;
            _validationService = validationService;
        }

        public List<Product> GetProducts()
        {
            List<Product> products = _context.Product.ToList();
            foreach (Product product in products.ToList())
            {
                if (!_validationService.IsProductValid(product.ID))
                {
                    products.Remove(product);
                }
            }

            return products;
        }

    }
}
