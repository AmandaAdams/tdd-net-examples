﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WishlistWebSite.Data;
using WishlistWebSite.Models;

namespace WishlistWebSite.Services
{
    public class WishlistService : IWishlistService
    {
        private readonly WishlistWebSiteContext _context;
        public Wishlist Wishlist { get; set; }

        public WishlistService(WishlistWebSiteContext context)
        {
            _context = context;
            Wishlist = new Wishlist();
        }

        
        public bool AddProduct(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            foreach (Product product in Wishlist.Products)
            {
                if (product.ID == id)
                {
                    return false;
                }
            }

            bool inDB = false;
            
            List<Product> dbproducts = _context.Product.ToList();

            foreach (Product product in dbproducts)
            {
                if (product.ID == id)
                {
                    inDB = true;
                    Wishlist.AddProduct(product);
                    break;
                }
            }

            return inDB;

        }

        public bool RemoveProduct(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            foreach (Product product in Wishlist.Products)
            {
                if (product.ID == id)
                {
                    Wishlist.RemoveProduct(product);
                    return true;
                }
            }
            return false;
        }
    }
}
