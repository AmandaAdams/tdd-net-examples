﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WishlistWebSite.Models;

namespace WishlistWebSite.Services
{
    public interface IProductService
    {
        List<Product> GetProducts();
    }
}
