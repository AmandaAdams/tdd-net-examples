﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace WishlistWebSite.Services
{
    public class ProductValidationService : IProductValidationService
    {
        public bool IsProductValid(int productId)
        {
            using (var client = new HttpClient())
            {
                var url = new Uri($"http://localhost:53801/isValid/" + productId);
                var response = client.GetAsync(url).Result;
                string json;
                using (var content = response.Content)
                {
                    json = content.ReadAsStringAsync().Result;
                }
                return json.Contains("true");
            }
        }
    }
}
