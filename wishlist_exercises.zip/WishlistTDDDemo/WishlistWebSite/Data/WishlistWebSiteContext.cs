﻿using Microsoft.EntityFrameworkCore;
using WishlistWebSite.Models;

namespace WishlistWebSite.Data
{
    public class WishlistWebSiteContext : DbContext
    {
        public WishlistWebSiteContext (DbContextOptions<WishlistWebSiteContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Product> Product { get; set; }
    }
}
