﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using WishlistWebSite.Services;

namespace WishlistWebSite.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IProductService _service;

        public ProductsController(IProductService service)
        {
            _service = service;

        }

        public IActionResult List()
        {
            return View(_service.GetProducts());
        }

    }
}
