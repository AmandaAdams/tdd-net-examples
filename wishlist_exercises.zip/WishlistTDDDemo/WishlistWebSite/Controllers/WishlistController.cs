﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WishlistWebSite.Models;
using WishlistWebSite.Services;

namespace WishlistWebSite.Controllers
{
    public class WishlistController : Controller
    {
        private readonly IWishlistService _service;

        public WishlistController(IWishlistService service)
        {
            _service = service;
        }

        public IActionResult AddProduct(int id)
        {
            HandleSessionSetup();

            _service.AddProduct(id);

            StoreToSession();
            return View("DefaultList", _service.Wishlist);
        }

        public IActionResult RemoveProduct(int id)
        {
            HandleSessionSetup();

            _service.RemoveProduct(id);

            StoreToSession();
            return View("DefaultList", _service.Wishlist);
        }

        private void HandleSessionSetup()
        {
            if (HttpContext.Session.Keys.Contains("DefaultWishlist"))
            {
                _service.Wishlist = JsonConvert
                    .DeserializeObject<Wishlist>(HttpContext.Session.GetString("DefaultWishlist"));
            }
            else
            {
                _service.Wishlist = new Wishlist();
            }
        }

        private void StoreToSession()
        {
            var serialisedList = JsonConvert.SerializeObject(_service.Wishlist);
            HttpContext.Session.SetString("DefaultWishlist", serialisedList);
        }
    }
}