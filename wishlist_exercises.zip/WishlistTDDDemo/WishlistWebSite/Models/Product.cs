using System;

namespace WishlistWebSite.Models
{
    public class Product
    {
        public string Name { get; set; }

        public int ID { get; set; }
    }
}