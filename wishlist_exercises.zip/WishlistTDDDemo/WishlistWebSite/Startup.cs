﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using WishlistWebSite.Data;
using WishlistWebSite.Services;
using System;

namespace WishlistWebSite
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDistributedMemoryCache();

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromSeconds(60);
                options.Cookie.HttpOnly = true;
            });

            services.AddMvc();

            services.AddDbContext<WishlistWebSiteContext>(options =>
                    options.UseSqlServer(Configuration.GetConnectionString("WishlistWebSiteContext")));

            services.AddScoped<IProductService, ProductService>();
            services.AddSingleton<IProductValidationService, ProductValidationService>();

            services.AddScoped<IWishlistService, WishlistService>();
        }

         public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }

            app.UseStaticFiles();
            app.UseSession();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Products}/{action=List}");
                routes.MapRoute(
                    name: "add",
                    template: "{controller=Wishlist}/{action=AddProduct}/{id}");
                routes.MapRoute(
                     name: "remove",
                     template: "{controller=Wishlist}/{action=RemoveProduct}/{id}");
                
            });
        }
    }
}
