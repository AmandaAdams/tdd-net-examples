﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Promotions
{
    public interface ITotalPromotion : IPromotion
    {
        bool PromotionApplies(decimal wishlistTotal);
    }
}
