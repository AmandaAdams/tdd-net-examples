﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Promotions
{
    public interface IItemPromotion : IPromotion
    {
        bool PromotionApplies(int numItems);
    }
}
