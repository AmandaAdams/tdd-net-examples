﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Promotions
{
    public class FreeShippingPromotion : ITotalPromotion
    {
        public bool PromotionApplies(decimal wishlistTotal)
        {
            bool applies = false;

            if (wishlistTotal < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            else if (wishlistTotal > 50)
            {
                applies = true;
            }

            return applies;

        }
    }
}
