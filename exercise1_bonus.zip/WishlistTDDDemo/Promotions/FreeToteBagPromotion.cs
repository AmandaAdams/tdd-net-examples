﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Promotions
{
    public class FreeToteBagPromotion : IItemPromotion
    {
        public bool PromotionApplies(int numItems)
        {
            bool applies = false;

            if (numItems < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            else if (numItems > 10)
            {
                applies = true;
            }

            return applies;

        }
    }
}
