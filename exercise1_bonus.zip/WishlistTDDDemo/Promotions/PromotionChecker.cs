﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Promotions
{
    public class PromotionChecker
    {
        public List<IPromotion> GetPromotions(decimal wishlistTotal, int numItems)
        {
            if (wishlistTotal < 0 || numItems < 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            var promotions = new List<IPromotion>();

            var freeShipping = new FreeShippingPromotion();
            if (freeShipping.PromotionApplies(wishlistTotal))
            {
                promotions.Add(freeShipping);
            }

            var twentyOff = new TwentyOffPromotion();
            if (twentyOff.PromotionApplies(wishlistTotal))
            {
                promotions.Add(twentyOff);
            }

            var freeTote = new FreeToteBagPromotion();
            if (freeTote.PromotionApplies(numItems))
            {
                promotions.Add(freeTote);
            }

            return promotions;

        }
    }
}
