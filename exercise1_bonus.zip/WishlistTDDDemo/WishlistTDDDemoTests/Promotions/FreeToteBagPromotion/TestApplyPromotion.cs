using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Promotions;

namespace WishlistTDDDemoTests.Promotions.FreeToteBagPromotionClass
{
    [TestClass]
    public class TestApplyPromotion
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeItemsThrowsArgumentOutofRangeException()
        {
            FreeToteBagPromotion promotion = new FreeToteBagPromotion();
            promotion.PromotionApplies(-1);
        }

        [TestMethod]
        public void ItemsBetweenZeroAnd10ReturnsFalse()
        {
            FreeToteBagPromotion promotion = new FreeToteBagPromotion();
            for (int i = 0; i <= 10; i++)
            {
                Assert.IsFalse(promotion.PromotionApplies(i));
            }
        }

        [TestMethod]
        public void ItemsGreaterThan10ReturnsTrue()
        {
            FreeToteBagPromotion promotion = new FreeToteBagPromotion();
            Assert.IsTrue(promotion.PromotionApplies(11));
        }
    }
}
